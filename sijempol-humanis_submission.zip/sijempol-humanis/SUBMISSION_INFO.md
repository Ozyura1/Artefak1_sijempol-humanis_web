# 📋 Submission Information - SiJempol Humanis

---

## Informasi Aplikasi

**Nama Aplikasi:** SiJempol Humanis - Sistem Informasi Administrasi Kependudukan Disdukcapil

**Deskripsi:** Aplikasi web modern untuk layanan administrasi kependudukan, meliputi layanan KTP, Kartu Keluarga, Perkawinan, Kelahiran, Kematian, dan Pindah Domisili. Dilengkapi dengan sistem OTP via email, dashboard admin, dan manajemen aspirasi masyarakat.

**Link Repository:**

```
https://github.com/[username]/sijempol-humanis
```

_(Anda akan mengisi username Anda sendiri)_

---

## 🛠️ Teknologi yang Digunakan

| Komponen            | Teknologi         | Versi  |
| ------------------- | ----------------- | ------ |
| **Frontend**        | Next.js           | 15.0.0 |
| **Frontend UI**     | React             | 19.0.0 |
| **Backend**         | Express.js        | Latest |
| **Database**        | JSON (File-based) | -      |
| **Authentication**  | JWT + bcryptjs    | -      |
| **Styling**         | Tailwind CSS      | 3.4.0  |
| **Package Manager** | npm/pnpm          | -      |

---

## ⚙️ Konfigurasi & Setup Aplikasi

### Prerequisites

- **Node.js** v18 atau lebih baru
- **npm** atau **pnpm** (untuk install dependencies)

### Langkah-Langkah Setup

#### 1. Clone Repository

```bash
git clone https://github.com/[username]/sijempol-humanis.git
cd sijempol-humanis
```

#### 2. Install Dependencies Frontend

```bash
npm install
# atau
pnpm install
```

#### 3. Install Dependencies Backend

```bash
cd backend
npm install
cd ..
```

#### 4. Setup Environment Variables

**Frontend** - Copy file `.env.local.example` menjadi `.env.local`:

```bash
cp .env.local.example .env.local
```

**Backend** - Copy file `.env.example` menjadi `.env`:

```bash
cd backend
cp .env.example .env
cd ..
```

Isi file `.env` backend dengan konfigurasi:

```env
PORT=8000
NODE_ENV=development
JWT_SECRET=your-secret-key-here
DATABASE_PATH=./data/database.json
ADMIN_PASSWORD=admin123
FRONTEND_URL=http://localhost:3000
EMAIL_SERVICE=gmail
EMAIL_USER=your-email@gmail.com
EMAIL_APP_PASSWORD=your-app-password
```

#### 5. Jalankan Backend

Di terminal pertama:

```bash
cd backend
npm start
```

Backend akan berjalan di `http://localhost:8000`

#### 6. Jalankan Frontend

Di terminal kedua (dari root directory):

```bash
npm run dev
```

Frontend akan berjalan di `http://localhost:3000`

#### 7. Akses Aplikasi

- **Frontend (User):** http://localhost:3000
- **Admin Dashboard:** http://localhost:3000/admin/login
- **API Base:** http://localhost:8000/api

---

## 🗄️ Database

**Tipe Database:** JSON (File-based)

**Lokasi File:** `backend/data/database.json`

**Struktur Database:**

```
{
  "users": [...],
  "agendas": [...],
  "aspirasis": [...],
  "addresses": [...],
  "id_cards": [...]
}
```

### Catatan Database

- Data disimpan dalam format JSON
- Database akan otomatis terbuat saat backend pertama kali dijalankan
- Backup database dengan cara copy file `backend/data/database.json`
- Untuk production, gunakan database relasional (MySQL/PostgreSQL) dengan modifikasi API

---

## 👥 Role & Akun Testing

Aplikasi ini memiliki **2 role** utama:

### 1. Admin (Administrator)

**Role:** Mengelola submissions, view reports, export data

**Akun Testing:**

```
Username: admin
Password: admin123
```

**Akses:** http://localhost:3000/admin/login

**Fitur Admin:**

- Dashboard overview
- View semua submissions (KTP, KK, Perkawinan, dll)
- Approve/Reject submissions
- View aspirasi masyarakat
- Export data CSV
- Manage user accounts

---

### 2. User (Warga Biasa)

**Role:** Submit form permohonan layanan administrasi

**Akun Testing:**

```
Username: demouser
Password: user123
```

**Akses:** http://localhost:3000/dashboard/login

**Fitur User:**

- Register akun baru (dengan OTP verification)
- Login
- Submit form layanan (KTP, KK, Perkawinan, Kelahiran, Kematian, Pindah)
- View status submission
- View history aspirasi

---

## 🧪 Testing Checklist

Setelah setup, coba test fitur berikut:

### Test Login Admin

```
1. Buka http://localhost:3000/admin/login
2. Masukkan: admin / admin123
3. Cek dashboard tampil dengan statistik submissions
```

### Test Login User

```
1. Buka http://localhost:3000/dashboard/login
2. Masukkan: demouser / user123
3. Cek bisa akses form layanan di dashboard
```

### Test API

```bash
# Test login backend
curl -X POST http://localhost:8000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"admin123"}'

# Response akan berupa JWT token
```

---

## 📁 Struktur Folder

```
sijempol-humanis/
├── app/                          # Next.js app directory
│   ├── admin/                    # Admin pages
│   │   ├── login/
│   │   ├── dashboard/
│   │   ├── database/
│   │   └── submissions/
│   ├── auth/                     # Authentication pages
│   ├── dashboard/                # User dashboard
│   ├── layanan/                  # Service pages (KTP, KK, dll)
│   ├── layout.tsx                # Root layout
│   └── page.tsx                  # Home page
├── backend/                      # Express.js backend
│   ├── routes/                   # API routes
│   ├── middleware/               # Custom middleware
│   ├── utils/                    # Utility functions (email, etc)
│   ├── data/
│   │   └── database.json         # JSON database
│   ├── server.js                 # Express server
│   ├── db.js                     # Database handler
│   └── package.json
├── components/                   # React components
│   ├── ui/                       # UI components (button, card, dll)
│   ├── auth/                     # Auth components
│   ├── dashboard/                # Dashboard components
│   └── forms/                    # Form components
├── lib/                          # Utility libraries
├── types/                        # TypeScript types
├── public/                       # Static assets
├── next.config.mjs               # Next.js config
├── tailwind.config.ts            # Tailwind CSS config
├── tsconfig.json                 # TypeScript config
├── package.json                  # Frontend dependencies
└── .gitignore                    # Git ignore rules
```

---

## 🐛 Troubleshooting

### Port Sudah Terpakai

Jika mendapat error `EADDRINUSE`, ubah PORT di `.env` backend atau frontend.

**Backend (.env):**

```env
PORT=8001
```

**Frontend (.env.local):**

```env
NEXT_PUBLIC_API_URL=http://localhost:8001/api
```

### Module Not Found

Pastikan sudah jalankan:

```bash
npm install
cd backend && npm install
```

### Database File Not Found

File database.json akan otomatis terbuat saat backend pertama kali dijalankan.

### CORS Error

Pastikan `FRONTEND_URL` di `backend/.env` sesuai dengan URL frontend Anda.

```env
FRONTEND_URL=http://localhost:3000
```

---

## 📝 Catatan Penting

1. **Development Environment Only:**
   - Aplikasi ini di-setup untuk development
   - Untuk production, gunakan database relasional (MySQL/PostgreSQL)
   - Aktifkan HTTPS dan konfigurasi keamanan yang proper

2. **Email OTP:**
   - Untuk testing OTP via email, konfigurasi Gmail app password di `.env`
   - Atau disable email verification untuk development

3. **Secret Key:**
   - Generate JWT_SECRET yang kuat untuk production
   - Jangan commit secret key ke repository

4. **Database Persistence:**
   - JSON database hanya cocok untuk development
   - Untuk production volume, migrasi ke MySQL/PostgreSQL

---

## 📞 Support

Jika ada pertanyaan atau error, cek file dokumentasi lainnya:

- [SETUP.md](./SETUP.md) - Setup detail
- [QUICK_START.md](./QUICK_START.md) - Quick start guide
- [ARCHITECTURE.md](./ARCHITECTURE.md) - Architecture overview
- [COMPLETE_IMPLEMENTATION_SUMMARY.md](./COMPLETE_IMPLEMENTATION_SUMMARY.md) - Feature summary

---

**Last Updated:** May 30, 2026

**Status:** ✅ Ready for Submission
