# 📊 Database Information

## Tipe Database

**Format:** JSON (File-based)  
**Lokasi:** `backend/data/database.json`  
**Engine:** Node.js File System (fs module)

---

## Struktur Database

```json
{
  "users": [
    {
      "id": 1,
      "username": "string",
      "password": "bcrypt_hash",
      "name": "string",
      "email": "string",
      "role": "admin | user",
      "created_at": "ISO8601_timestamp"
    }
  ],
  "agendas": [],
  "aspirasis": [],
  "addresses": [],
  "id_cards": [
    {
      "id": 1,
      "user_id": 1,
      "applicant_name": "string",
      "status": "pending | approved | rejected",
      "data": {
        /* KTP form data */
      },
      "documents": {
        /* uploaded files */
      },
      "created_at": "ISO8601_timestamp",
      "updated_at": "ISO8601_timestamp"
    }
  ]
}
```

---

## Tabel & Field Penjelasan

### 1. `users` - Data Pengguna

| Field        | Type   | Deskripsi                    |
| ------------ | ------ | ---------------------------- |
| `id`         | Number | Unique user ID               |
| `username`   | String | Username untuk login         |
| `password`   | String | Password ter-hash (bcryptjs) |
| `name`       | String | Nama lengkap                 |
| `email`      | String | Email pengguna               |
| `role`       | String | Role (admin/user)            |
| `created_at` | String | Timestamp pembuatan akun     |

### 2. `agendas` - Agenda Disdukcapil

| Field         | Type   | Deskripsi        |
| ------------- | ------ | ---------------- |
| `id`          | Number | Unique agenda ID |
| `title`       | String | Judul agenda     |
| `date`        | String | Tanggal agenda   |
| `time`        | String | Jam agenda       |
| `description` | String | Deskripsi agenda |

### 3. `aspirasis` - Aspirasi/Keluhan Masyarakat

| Field        | Type   | Deskripsi                      |
| ------------ | ------ | ------------------------------ |
| `id`         | Number | Unique aspirasi ID             |
| `name`       | String | Nama pelapor                   |
| `email`      | String | Email pelapor                  |
| `phone`      | String | No. HP pelapor                 |
| `subject`    | String | Subjek aspirasi                |
| `message`    | String | Isi pesan                      |
| `status`     | String | Status (pending/seen/resolved) |
| `created_at` | String | Timestamp                      |

### 4. `addresses` - Data Alamat

| Field       | Type   | Deskripsi         |
| ----------- | ------ | ----------------- |
| `id`        | Number | Unique address ID |
| `provinsi`  | String | Provinsi          |
| `kabupaten` | String | Kabupaten/Kota    |
| `kecamatan` | String | Kecamatan         |
| `kelurahan` | String | Kelurahan         |
| `rt_rw`     | String | RT/RW             |

### 5. `id_cards` - Permohonan KTP

| Field            | Type   | Deskripsi                          |
| ---------------- | ------ | ---------------------------------- |
| `id`             | Number | Unique submission ID               |
| `user_id`        | Number | ID user yang submit                |
| `applicant_name` | String | Nama pemohon                       |
| `status`         | String | Status (pending/approved/rejected) |
| `data`           | Object | Form data KTP                      |
| `documents`      | Object | Dokumen upload                     |
| `created_at`     | String | Timestamp submit                   |
| `updated_at`     | String | Timestamp update                   |

_Format serupa berlaku untuk: `kk`, `perkawinan`, `kelahiran`, `kematian`, `pindah`_

---

## Akun Testing Default

Database dilengkapi dengan akun testing berikut:

### Admin Account

```json
{
  "id": 1,
  "username": "admin",
  "password": "$2a$10$m8KWavcLB800TebgQEsaqen.oBDUZnXYqYuIfkOtFOfZCZYkdSjTC",
  "name": "Admin Disdukcapil",
  "email": "admin@disdukcapil.go.id",
  "role": "admin",
  "created_at": "2026-04-25T17:45:16.569Z"
}
```

**Login:** `admin` / `admin123`

### Demo User Account

```json
{
  "id": 7,
  "username": "demouser",
  "password": "$2a$10$krmU9L23gvV6ut2WT4aI.upkO9TTsfL8glVB9M3eBhSP2R2I7qzfq",
  "name": "Demo User",
  "email": "demouser@example.com",
  "role": "user",
  "created_at": "2026-05-30T00:00:00.000Z"
}
```

**Login:** `demouser` / `user123`

---

## Backup & Restore

### Backup Database

```bash
# Copy file database
cp backend/data/database.json backend/data/database.backup.json
```

### Restore Database

```bash
# Restore dari backup
cp backend/data/database.backup.json backend/data/database.json
```

### Reset Database

```bash
# Hapus database untuk reset (akan otomatis terbuat ulang saat restart backend)
rm backend/data/database.json
```

---

## Migrasi ke SQL (MySQL/PostgreSQL)

Jika ingin migrasi dari JSON ke database relasional:

### MySQL SQL Schema

```sql
-- Create users table
CREATE TABLE users (
  id INT PRIMARY KEY AUTO_INCREMENT,
  username VARCHAR(255) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL,
  name VARCHAR(255) NOT NULL,
  email VARCHAR(255) UNIQUE NOT NULL,
  role ENUM('admin', 'user') NOT NULL DEFAULT 'user',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create id_cards table
CREATE TABLE id_cards (
  id INT PRIMARY KEY AUTO_INCREMENT,
  user_id INT NOT NULL,
  applicant_name VARCHAR(255) NOT NULL,
  status ENUM('pending', 'approved', 'rejected') NOT NULL DEFAULT 'pending',
  data JSON,
  documents JSON,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Create agendas table
CREATE TABLE agendas (
  id INT PRIMARY KEY AUTO_INCREMENT,
  title VARCHAR(255) NOT NULL,
  date DATE NOT NULL,
  time TIME,
  description TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create aspirasis table
CREATE TABLE aspirasis (
  id INT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(255) NOT NULL,
  email VARCHAR(255),
  phone VARCHAR(20),
  subject VARCHAR(255) NOT NULL,
  message TEXT NOT NULL,
  status ENUM('pending', 'seen', 'resolved') NOT NULL DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create addresses table
CREATE TABLE addresses (
  id INT PRIMARY KEY AUTO_INCREMENT,
  provinsi VARCHAR(100),
  kabupaten VARCHAR(100),
  kecamatan VARCHAR(100),
  kelurahan VARCHAR(100),
  rt_rw VARCHAR(20)
);
```

### Untuk Production:

1. Install database driver (e.g., `mysql2` atau `pg`)
2. Update `backend/db.js` untuk query database
3. Setup `.env` dengan database credentials
4. Run migrations
5. Update API routes untuk query SQL

---

## Password Hashing

Password menggunakan **bcryptjs** dengan salt rounds 10.

**Hash untuk password testing:**

- `admin123` → `$2a$10$m8KWavcLB800TebgQEsaqen.oBDUZnXYqYuIfkOtFOfZCZYkdSjTC`
- `user123` → `$2a$10$krmU9L23gvV6ut2WT4aI.upkO9TTsfL8glVB9M3eBhSP2R2I7qzfq`

Untuk generate hash baru:

```bash
node -e "const bcrypt = require('bcryptjs'); console.log(bcrypt.hashSync('password123', 10))"
```

---

## Data Persistence

**Development:** Data tersimpan di file `backend/data/database.json`

**Production Recommendation:**

- Gunakan MySQL atau PostgreSQL
- Backup regular database
- Implementasi database replication
- Setup monitoring dan alerting

---

**Last Updated:** May 30, 2026
